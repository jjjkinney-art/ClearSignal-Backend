"""
Business logic for orchestrating AI analyst agents.

Enterprise integration:
  - All stages emit observability spans
  - Provider governance filters sources before evidence build
  - Audit record is always emitted (not gated behind a flag)
  - Tenant/user scope is extracted and propagated to evidence layer
  - request_id and trace_id flow through the full lifecycle
"""

import uuid
import logging
import json
import time
from typing import List, Optional

from ..schemas import (
    AnalysisRequest,
    AnalysisResponse,
    EquityAnalysis,
    MacroAnalysis,
    OpportunityAnalysis,
    ResearchAnalysis,
    EducationAnalysis,
    AccountingAnalysis,
    GroundingContext,
    SynthesisOutput,
)
from ..agents import (
    run_equity_agent,
    run_macro_agent,
    run_opportunity_agent,
    run_research_agent,
    run_education_agent,
    run_accounting_agent,
    run_synthesizer_agent,
)
from .router_service import classify_question
from .context_service import enrich_grounding_context
from .evidence_service import select_evidence_sources, build_evidence

# ── Enterprise layer — always imported, degrades gracefully ───────────────
try:
    from ..enterprise.observability import get_tracer, start_span, finish_trace, log_event
    from ..enterprise.audit import audit_store, AnalysisAuditRecord
    from ..enterprise.provider_registry import (
        provider_registry, get_provider_chain, CapabilityType, ProviderPolicy,
    )
    from ..enterprise.tenant import get_scope, ScopeContext
    from ..enterprise.cache import response_cache, provider_cache_key
    _ENTERPRISE = True
except Exception:
    _ENTERPRISE = False

logger = logging.getLogger(__name__)


# ── Null context manager for when trace is unavailable ────────────────────
from contextlib import contextmanager as _cm

@_cm
def _null_span():
    class _N:
        def set_tag(self, *a, **kw): pass
    yield _N()


def analyze_company(
    request: AnalysisRequest,
    scope: Optional["ScopeContext"] = None,
) -> AnalysisResponse:
    """Run the full analysis workflow for a given request.

    Enterprise path (always active):
        1. Start observability trace
        2. Resolve tenant/user scope
        3. Governance: filter allowed evidence sources
        4. Evidence build (with spans, governed calls, history_ops, cache)
        5. Routing + agent execution (with per-agent spans)
        6. Synthesis
        7. Emit full audit record
        8. Finish trace
    """
    request_id = str(uuid.uuid4())
    company    = request.company_name
    t_start    = time.perf_counter()

    # ── 1. Start observability trace ──────────────────────────────────────
    trace = None
    if _ENTERPRISE:
        try:
            trace = get_tracer(request_id=request_id)
            trace.set_metadata("company",  company)
            trace.set_metadata("question", request.user_question or "")
        except Exception:
            trace = None

    # ── 2. Resolve scope ──────────────────────────────────────────────────
    if scope is None and _ENTERPRISE:
        try:
            scope = get_scope(getattr(request, "session_id", "") or
                              getattr(request, "user_id", "") or "")
        except Exception:
            scope = None

    # Attach request_id and scope to context so evidence layer can use them
    _base_ctx = getattr(request, "context", None)

    with (start_span(trace, "context_enrichment") if trace else _null_span()) as sp:
        try:
            context = enrich_grounding_context(company, request.user_question, _base_ctx)
            # Propagate request_id and scope into grounding context
            try:
                object.__setattr__(context, "request_id", request_id)
            except Exception:
                pass
            if scope is not None:
                try:
                    object.__setattr__(context, "scope", scope)
                except Exception:
                    pass
        except Exception as exc:
            logger.error(json.dumps({"event": "context_enrichment_error",
                                     "error": str(exc), "request_id": request_id}))
            context = GroundingContext(company=company)

    # ── 3. Governance: determine allowed sources ──────────────────────────
    with (start_span(trace, "evidence_selection") if trace else _null_span()) as sp:
        try:
            evidence_decision  = select_evidence_sources(request.user_question)
            selected_sources   = evidence_decision.get("selected_sources", [])
        except Exception as exc:
            logger.error(json.dumps({"event": "evidence_selection_error",
                                     "error": str(exc), "request_id": request_id}))
            evidence_decision  = {"selected_sources": [], "skipped_sources": [],
                                   "reasons": {}, "confidence": 0.0}
            selected_sources   = []

        # Filter sources through governance when enterprise is available
        if _ENTERPRISE and provider_registry is not None:
            try:
                from ..config import settings as _cfg
                has_fmp_key = bool(getattr(_cfg, "fmp_api_key", ""))
                pol = ProviderPolicy(require_citeable=True)
                # Remove sources denied by scope restrictions
                if scope is not None:
                    selected_sources = [s for s in selected_sources
                                        if scope.can_access_source(s)]
                # Remove sources denied by governance policy
                governed = []
                for src in selected_sources:
                    dec = provider_registry.check_access(
                        src, policy=pol,
                        has_api_key=(has_fmp_key if src == "fmp" else True)
                    )
                    if dec.allowed:
                        governed.append(src)
                    else:
                        logger.info(json.dumps({"event": "source_denied_by_governance",
                                                "source": src, "reason": dec.reason,
                                                "request_id": request_id}))
                selected_sources = governed
            except Exception:
                pass  # governance errors are non-fatal
        if sp:
            sp.set_tag("sources", selected_sources)
            sp.set_tag("governance_applied", _ENTERPRISE)

    # ── 4. Evidence build ─────────────────────────────────────────────────
    with (start_span(trace, "evidence_build", {"sources": selected_sources})
          if trace else _null_span()) as sp:
        try:
            context = build_evidence(
                company, context.ticker or company,
                request.user_question, selected_sources, context
            )
            if sp:
                sp.set_tag("known_facts_count",
                           len(getattr(context, "known_facts", [])))
                sp.set_tag("historical_meanings",
                           list(getattr(context, "historical_meanings", {}).keys()))
        except Exception as exc:
            logger.error(json.dumps({"event": "evidence_build_error",
                                     "error": str(exc), "request_id": request_id}))

    t_evidence_end = time.perf_counter()
    logger.info(json.dumps({"event": "evidence_built", "request_id": request_id,
                            "duration": t_evidence_end - t_start}))

    # ── 5. Routing ────────────────────────────────────────────────────────
    with (start_span(trace, "routing") if trace else _null_span()) as sp:
        if request.user_question:
            routing_decision = classify_question(request.user_question)
        else:
            routing_decision = classify_question("")
        selected_agents: List[str] = routing_decision.get("selected_agents", [])
        if sp:
            sp.set_tag("agents", selected_agents)

    logger.info(json.dumps({"event": "analysis_started", "request_id": request_id,
                            "company": company, "question": request.user_question,
                            "routing": routing_decision}))

    # ── 6. Agent execution ────────────────────────────────────────────────
    equity      = EquityAnalysis()
    macro       = MacroAnalysis()
    opportunity = OpportunityAnalysis()
    research    = ResearchAnalysis()
    education   = EducationAnalysis()
    accounting  = AccountingAnalysis()

    _AGENT_RUNNERS = {
        "equity":      lambda: run_equity_agent(company, context=context,
                                                 user_question=request.user_question,
                                                 request_id=request_id),
        "macro":       lambda: run_macro_agent(company, context=context,
                                               request_id=request_id),
        "opportunity": lambda: run_opportunity_agent(company, context=context,
                                                      request_id=request_id),
        "research":    lambda: run_research_agent(company, context=context,
                                                   request_id=request_id),
        "education":   lambda: run_education_agent(company, context=context,
                                                    request_id=request_id),
        "accounting":  lambda: run_accounting_agent(company, context=context,
                                                     request_id=request_id),
    }
    _AGENT_DEFAULTS = {
        "equity": EquityAnalysis, "macro": MacroAnalysis,
        "opportunity": OpportunityAnalysis, "research": ResearchAnalysis,
        "education": EducationAnalysis, "accounting": AccountingAnalysis,
    }

    agent_errors: List[str] = []
    for agent in selected_agents:
        runner = _AGENT_RUNNERS.get(agent)
        if runner is None:
            continue
        with (start_span(trace, f"agent_{agent}") if trace else _null_span()) as sp:
            try:
                a_start = time.perf_counter()
                result  = runner()
                a_dur   = time.perf_counter() - a_start
                if sp:
                    sp.set_tag("duration_ms", a_dur * 1000)
                logger.info(json.dumps({"event": "agent_timing", "agent": agent,
                                        "duration": a_dur, "request_id": request_id}))
                if agent == "equity":      equity      = result
                elif agent == "macro":     macro       = result
                elif agent == "opportunity": opportunity = result
                elif agent == "research":  research    = result
                elif agent == "education": education   = result
                elif agent == "accounting": accounting  = result
            except Exception as exc:
                agent_errors.append(agent)
                logger.error(json.dumps({"event": "agent_error", "agent": agent,
                                         "error": str(exc), "request_id": request_id}))
                default_cls = _AGENT_DEFAULTS.get(agent)
                if default_cls:
                    result = default_cls()
                    if agent == "equity":      equity      = result
                    elif agent == "macro":     macro       = result
                    elif agent == "opportunity": opportunity = result
                    elif agent == "research":  research    = result
                    elif agent == "education": education   = result
                    elif agent == "accounting": accounting  = result

    # ── 7. Synthesis ──────────────────────────────────────────────────────
    with (start_span(trace, "synthesis") if trace else _null_span()) as sp:
        try:
            synthesis = run_synthesizer_agent(
                company, equity, macro, opportunity,
                research, education, accounting,
                context=context, request_id=request_id,
            )
        except Exception as exc:
            logger.error(json.dumps({"event": "agent_error", "agent": "synthesizer",
                                     "error": str(exc), "request_id": request_id}))
            synthesis = SynthesisOutput()  # type: ignore[name-defined]

    # Signal ranking (unchanged)
    try:
        from .prioritization_utils import rank_signals
        focus = request.user_focus
        if synthesis.key_drivers_ranked:
            synthesis.key_drivers_ranked = rank_signals(
                synthesis.key_drivers_ranked,
                top_n=len(synthesis.key_drivers_ranked), focus=focus)
        if synthesis.key_risks_ranked:
            synthesis.key_risks_ranked = rank_signals(
                synthesis.key_risks_ranked,
                top_n=len(synthesis.key_risks_ranked),
                focus=focus if focus == "risk" else None)
        if synthesis.key_catalysts:
            synthesis.key_catalysts = rank_signals(
                synthesis.key_catalysts,
                top_n=len(synthesis.key_catalysts), focus=focus)
        if synthesis.macro_overlay and focus == "macro":
            synthesis.macro_overlay = rank_signals(
                synthesis.macro_overlay,
                top_n=len(synthesis.macro_overlay), focus=focus)
    except Exception:
        pass

    t_end = time.perf_counter()
    logger.info(json.dumps({"event": "analysis_duration", "request_id": request_id,
                            "duration": t_end - t_start}))

    # ── 8. Audit record — always emitted ─────────────────────────────────
    try:
        evidence_snapshot = {
            "known_facts_count":          len(getattr(context, "known_facts", [])),
            "has_market_snapshot":        getattr(context, "market_snapshot", None) is not None,
            "has_filings":                bool(getattr(context, "filings_context", [])),
            "historical_meanings_domains": list(getattr(context, "historical_meanings", {}).keys()),
            "scope_tenant":               getattr(scope, "tenant_id", "") if scope else "",
            "scope_user":                 getattr(scope, "user_id", "") if scope else "",
        }
        # Capture signal profile state for selected signals
        signal_profile_state: dict = {}
        try:
            from .learning import get_signal_profile
            question_tokens = (request.user_question or "").lower().split()[:3]
            for tok in question_tokens:
                if len(tok) > 4:
                    signal_profile_state[tok] = get_signal_profile(tok).get("signal_profile", "")
        except Exception:
            pass

        _model_name = ""
        try:
            from ..config import settings as _cfg
            _model_name = getattr(_cfg, "openai_model", "")
        except Exception:
            pass

        audit_record = AnalysisAuditRecord(
            request_id          = request_id,
            company             = company,
            user_question       = request.user_question or "",
            routing_decision    = routing_decision,
            evidence_sources    = selected_sources,
            evidence_snapshot   = evidence_snapshot,
            agents_used         = selected_agents,
            signal_profile_state = signal_profile_state,
            has_errors          = bool(agent_errors),
            trace_id            = trace.trace_id if trace else "",
            configuration       = {"model": _model_name,
                                   "enterprise": _ENTERPRISE},
            notes               = f"agent_errors: {agent_errors}" if agent_errors else "",
        )
        audit_store.record_analysis(audit_record)
    except Exception as exc:
        logger.warning(json.dumps({"event": "audit_emission_error",
                                   "error": str(exc), "request_id": request_id}))

    # Finish trace
    if _ENTERPRISE and trace:
        try:
            finish_trace(request_id)
        except Exception:
            pass

    logger.info(json.dumps({"event": "analysis_complete", "request_id": request_id,
                            "company": company, "agents_used": selected_agents,
                            "routing": routing_decision}))

    return AnalysisResponse(
        company    = company,
        request_id = request_id,
        equity     = equity,
        macro      = macro,
        opportunity = opportunity,
        research   = research,
        education  = education,
        accounting = accounting,
        synthesis  = synthesis,
        routing    = routing_decision,
    )
