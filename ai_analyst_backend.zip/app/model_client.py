"""
Centralized client for making OpenAI model calls with retry and timeout handling.

This module encapsulates all interactions with the OpenAI API.  It
provides a clean interface for sending messages and receiving text
responses.  It handles API key configuration, request metadata,
timeouts, retries with exponential backoff, and error normalization.

By routing all model calls through this client, the rest of the codebase
remains free of direct OpenAI dependencies and can be more easily
tested or swapped out for a different provider.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from typing import Any, List, Dict

# Attempt to import OpenAI.  In test environments the openai package may
# not be installed.  Gracefully fall back to a dummy error type to
# avoid import errors when the module is missing.  The actual API
# invocation will only occur if the ``call`` method is executed.
try:
    from openai import ChatCompletion, error as openai_error  # type: ignore
except ImportError:  # pragma: no cover - executed only when openai is absent
    ChatCompletion = None  # type: ignore
    # Create a dummy error type so that ``except openai_error.Timeout`` etc. still work
    class _DummyOpenAIError(Exception):  # type: ignore
        """Fallback error class used when openai package is unavailable."""

    openai_error = _DummyOpenAIError  # type: ignore

from .config import settings

logger = logging.getLogger(__name__)


class ModelClient:
    """Wrapper around the OpenAI ChatCompletion API with retries and logging."""

    def __init__(
        self,
        api_key: str,
        model: str,
        temperature: float,
        max_tokens: int,
        timeout: float = 30.0,
        max_retries: int = 3,
        backoff_factor: float = 0.5,
    ) -> None:
        # Lazily configure the OpenAI client if the package is available.  This
        # approach avoids import failures at module load time when openai
        # is not installed (e.g., during offline testing).  Only set
        # ``openai.api_key`` when the openai module exists.
        try:  # pragma: no cover - this branch depends on presence of openai
            import openai  # type: ignore
            openai.api_key = api_key
        except ImportError:
            pass
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    def call(self, prompt: str, system_prompt: str = "", request_id: str | None = None) -> str:
        """Call the OpenAI ChatCompletion API and return the response text.

        Parameters
        ----------
        prompt : str
            The user prompt to send to the model.
        system_prompt : str, optional
            An optional system-level prompt to prefix the conversation.
        request_id : str, optional
            Identifier for logging correlation.  If not provided, a new
            UUID will be generated.

        Returns
        -------
        str
            The content of the first choice returned by the API.

        Raises
        ------
        Exception
            If the API call fails after all retries.
        """
        if request_id is None:
            request_id = str(uuid.uuid4())
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        for attempt in range(1, self.max_retries + 1):
            try:
                start_time = time.time()
                # Guard against missing ChatCompletion in offline environments
                if ChatCompletion is None:  # pragma: no cover - offline fallback
                    raise openai_error("OpenAI package not available")  # type: ignore
                response = ChatCompletion.create(
                    model=self.model,
                    messages=messages,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    timeout=self.timeout,
                )
                duration = time.time() - start_time
                # Extract content from the first choice
                content = response.choices[0].message["content"]  # type: ignore[index]
                logger.info(
                    json.dumps({
                        "event": "model_call_success",
                        "request_id": request_id,
                        "attempt": attempt,
                        "duration_ms": int(duration * 1000),
                    })
                )
                return content
            except (openai_error.Timeout, getattr(openai_error, "APIError", openai_error), getattr(openai_error, "APIConnectionError", openai_error)) as exc:
                # Retry on OpenAI-specific errors
                logger.warning(
                    json.dumps({
                        "event": "model_call_retry",
                        "request_id": request_id,
                        "attempt": attempt,
                        "error": str(exc),
                    })
                )
                if attempt == self.max_retries:
                    raise
                # exponential backoff
                time.sleep(self.backoff_factor * (2 ** (attempt - 1)))
            except Exception as exc:
                # Fail immediately on unexpected exceptions
                logger.error(
                    json.dumps({
                        "event": "model_call_failure",
                        "request_id": request_id,
                        "attempt": attempt,
                        "error": str(exc),
                    })
                )
                raise


# Instantiate a default client using environment settings.  This instance
# can be imported throughout the codebase.  It relies on the OPENAI_API_KEY
# and related settings loaded via the Settings object.
model_client = ModelClient(
    api_key=settings.openai_api_key,
    model=settings.openai_model,
    temperature=settings.temperature,
    max_tokens=settings.max_tokens,
    timeout=settings.model_timeout,
    max_retries=settings.model_max_retries,
    backoff_factor=settings.model_backoff_factor,
)